export default {
  async fetch(request: Request, env: any, ctx: any) {
    const url = new URL(request.url);
    
    // Elsa API 路由
    if (url.pathname.startsWith('/api/chat/brain')) {
      return await handleElsaAPI(request, env);
    }
    
    // 其他路由
    return await handleFrontend(request);
  }
};

async function handleElsaAPI(request: Request, env: any): Promise<Response> {
  const { message } = await request.json();
  
  try {
    const response = await fetch(`${env.ELSA_API_URL}/api/chat/brain`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message })
    });
    
    return response;
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function handleFrontend(request: Request): Promise<Response> {
  return new Response('Elsa Mobile App', {
    headers: { 'Content-Type': 'text/html' }
  });
}
