const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// 禁用可能導致卡住的優化
config.resolver.unstable_enablePackageExports = false;

module.exports = config;
